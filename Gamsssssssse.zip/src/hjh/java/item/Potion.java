package hjh.java.item;

public class Potion {

}
